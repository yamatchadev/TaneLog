<?php
$clientid = "365673563519-2d6otm9s909f1kohohmqrf5iq8puonvf.apps.googleusercontent.com";
$clientsecret = "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";
?>