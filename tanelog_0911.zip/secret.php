<?php
$clientid = "365673563519-2d6otm9s909f1kohohmqrf5iq8puonvf.apps.googleusercontent.com";
$clientsecret = "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";

define('VAPID_SUBJECT', 'https://tanelog.yamatcha.net');
define('VAPID_PUBLIC_KEY', 'BIJpysyKVdnHSOxfBxtHyjd9W6xev8gVExcFmk3MJfotkgdG3SHatYrmi8oiarmazkdZgC5lzGEkBzmDNMMF42Y');
define('VAPID_PRIVATE_KEY', 'x80sObeYh1JFeLgp99osk3v9EpB8_PND1THFjs8SKfg');
?>