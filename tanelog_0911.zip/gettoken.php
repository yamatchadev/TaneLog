<?php
require 'vendor/autoload.php';

$client = new Google\Client();
$client->setClientId('365673563519-2d6otm9s909f1kohohmqrf5iq8puonvf.apps.googleusercontent.com');      // 新しく作ったもの
$client->setClientSecret('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'); // 新しく作ったもの
$client->setRedirectUri('http://localhost:10001/learnphp/callback.php');
$client->addScope(Google\Service\Gmail::GMAIL_SEND);
$client->setAccessType('offline');
$client->setPrompt('consent');

$authUrl = $client->createAuthUrl();
header('Location: ' . $authUrl);
exit;