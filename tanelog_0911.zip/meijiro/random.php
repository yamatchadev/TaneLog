<?php
require_once 'db.php';

try {
    // 【修正ポイント】
    // content_id の文字数が 15桁未満 のもの、または空のものをすべて抽出します。
    // これにより、古い '2147483647'（10桁）や空のデータが確実にすべてヒットします。
    $stmt = $pdo->query("SELECT id FROM posts WHERE CHAR_LENGTH(content_id) < 15 OR content_id IS NULL OR content_id = ''");
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "更新対象の投稿数: " . count($posts) . " 件<br><br>";

    if (count($posts) > 0) {
        // 更新用のプリペアドステートメントを準備
        $updateStmt = $pdo->prepare("UPDATE posts SET content_id = ? WHERE id = ?");

        $successCount = 0;

        // 1件ずつランダムな15桁を生成して更新
        foreach ($posts as $post) {
            $postId = $post['id'];

            // 確実な15桁のランダムな数字文字列を生成
            $randomId = '';
            for ($i = 0; $i < 15; $i++) {
                $randomId .= random_int(0, 9);
            }

            // データベースを更新
            $updateStmt->execute([$randomId, $postId]);
            $successCount++;
        }

        echo "<strong>一括更新が完了しました！</strong><br>";
        echo "更新成功: " . $successCount . " 件";
    } else {
        echo "更新対象のデータが見つかりませんでした。すでにすべての投稿に15桁のIDが割り振られている可能性があります。";
    }

} catch (Exception $e) {
    echo "エラーが発生しました: " . htmlspecialchars($e->getMessage());
}