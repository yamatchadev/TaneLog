<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $pass = htmlspecialchars($_POST['pass']);    
    $id = htmlspecialchars($_POST['id']);
    if($pass === 'deletealldata'){
        require_once '../db.php';
        $stmt_posts = $pdo->prepare("DELETE FROM posts WHERE user_id = ?");
        $stmt_posts->execute([$id]);
      
        // 2. ユーザーアカウントの削除
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);            
    }
}
?>
<html>
    <body>
        <form action="admin.php" method="post">
            <input type="text" name="id" placeholder="id">
            <input type="text" name="pass" placeholder="pass">
            <button type="submit">Go</button>
        </form>
    </body>
</html>