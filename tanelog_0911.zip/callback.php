<?php
require 'vendor/autoload.php';

$client = new Google\Client();
$client->setClientId('365673563519-2d6otm9s909f1kohohmqrf5iq8puonvf.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost:10001/learnphp/callback.php');

$token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

if (isset($token['error'])) {
    die("エラー: " . $token['error_description']);
}

file_put_contents(__DIR__ . '/token.json', json_encode($token));
echo "token.json を保存しました！トークン取得完了です。";