<?php
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

$dsn  = 'mysql:host=localhost;dbname=photoapp;charset=utf8mb4';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    $_SESSION['error'] = $e->getMessage();
    //エラーが起きたファイルの名前を取得
    $files = get_included_files();
    $_SESSION['caller'] = $files[count($files) - 2];
    header('Location: dberror.php');
    exit();
}
?>