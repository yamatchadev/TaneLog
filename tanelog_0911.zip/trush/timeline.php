<?php
require_once 'logincheck.php';
require_once 'db.php';

// 投稿フォーム処理
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = htmlspecialchars($_POST['content']);
    $stmt = $pdo->prepare(
        "INSERT INTO posts (user_id, content) VALUES (?, ?)"
    );
    $stmt->execute(
        [
            $_SESSION['user_id'], $content
        ]
    );
    header('Location: timeline.php');
    exit;
}

// 投稿一覧取得（投稿者名も一緒に）
$posts = $pdo->query(
    "SELECT posts.*, users.name FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC"
)->fetchAll();
?>
<html lang="ja">
    <head>
        <meta charset="UTF-8">
    </head>
    <header>
        <div>
            <img src="logo.png" alt="learnPHP's Logo">
            <a href="logout.php"><button>ログアウト</button></a>
        </div>
    </header>
    <body>
        <form action="timeline.php" method="post">
            <textarea name="content"></textarea>
            <button type="submit">投稿</button>
        </form>
        <?php foreach ($posts as $p): ?>
            <p><b><?=  htmlspecialchars($p['name']) ?></b><?php //<?= は <?php echo の短縮形 ?>
        <?= htmlspecialchars($p['content']) ?></p>
        <?php endforeach; ?>
    </body>
</html>