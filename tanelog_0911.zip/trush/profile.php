<?php
require_once 'db.php';
require_once 'logincheck.php';
if(!isset($_GET['username'])){
    header('Location: timeline.php');
    exit;
} else {
    $username = htmlspecialchars($_GET['username']);
    $stmt = $pdo->prepare("SELECT icon_path, created_at, profile_statement, nickname FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    $currentIcon = $user['icon_path'];
    echo $currentIcon;
    $iconSrc = ($currentIcon && file_exists(__DIR__ . '/' . $currentIcon))
    ? htmlspecialchars($currentIcon)
    : 'https://ui-avatars.com/api/?name=' . urlencode($user['nickname'] ?? 'U') . '&background=4F5D95&color=fff';
}
?>
<html>
    <head>
        <style>

        </style>
    </head>
    <body>
        <p><?php echo $username;?></p>
        <img src="<?= $iconSrc ?>" alt="アイコン">
        <p><?= htmlspecialchars($user['created_at']) ?></p>
        <p><?= htmlspecialchars($user['profile_statement']) ?></p>
    </body>
</html>