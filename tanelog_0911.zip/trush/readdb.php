<?php
require_once '../db.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){
    // 条件付き取得（プリペアドステートメント）
    $id   = $_GET['id'] ?? 1;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetchAll();  // 1行だけ取得
    foreach($user as $u) {
        echo htmlspecialchars($u['name']) . "/"
        . htmlspecialchars($u['email']) . "<br>";
    }
}else{

    // 全件取得
    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at ASC");
    $users = $stmt->fetchAll(); // 全行を配列で取得

    foreach($users as $u) {
        echo htmlspecialchars($u['name']) . "/"
        . htmlspecialchars($u['email']) . "<br>";
    }
}
?>