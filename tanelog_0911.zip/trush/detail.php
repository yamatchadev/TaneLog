<?PHP
if(isset($_GET['contentid'])){
    require_once 'db.php';
    $contentid = htmlspecialchars($_GET['contentid']);
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE content_id = ?");
    $stmt->execute([$contentid]);
    $post = $stmt->fetch();
    $user_id = $post['user_id'];

    $stmt_by = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_by->execute([$user_id]);
    $post_user = $stmt_by->fetch();
    if($post_user){
    echo $post_user['nickname'];
    echo $contentid;
    }else{
        echo "false";
    }
}
?>
<html>
    <head>

    </head>
    <body>
        <p><?= htmlspecialchars($post['content']); ?></p>
    </body>
</html>